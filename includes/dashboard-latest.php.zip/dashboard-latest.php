<?php
global $wpdb;
$table = $wpdb->prefix . 'pie_ext';


$pending_users = $wpdb->get_results("SELECT * FROM $table WHERE `verified`='n' ");


$pending_users_sanitized = array();

foreach($pending_users as $user){
	$pending_users_sanitized[$user->id][] = $user;
}

$user_profile = get_option('siteurl') . "/wp-admin/user-edit.php?user_id=";

	
?>

	<div">
		<span style="float:left;"> <strong>Name: </strong> <?php echo get_user_meta($user_id,'first_name',true) . ' ' . get_user_meta($user_id,'last_name',true); ?> </span> <span style="float:right;"> <strong>Registration Date: </strong> Dec 12,2011</span>
	</div>
	<div style="clear:both;"></div>
	<table class="widefat" style="margin-top:10px;">
		<tr>
			<th>Healing Modalities</th> <th>Verification</th> <th>Status</th> <th>Action</th>		
		</tr>
		<?php 
			foreach($pending_users_sanitized as $user_id=>$san_user){
			$approve_class = $user_id . '-';
		?>
		
		<tr>
			<?php foreach($san_user as $su){ ?>				
				<td><?php echo $su->modal; ?></td>
				
				<?php 
					if($su->type == 'd'){
											
						echo "<td><a href='#'>Certificate</a></td>";
						echo "<td>pending</td>";						
						echo "<td> <a href='#'>Delete</a> / <a href='#'>Approve</a> </td>";
		echo "</tr>";
		
					}
					else{ 
						echo "<td>Reference Emails</td>";
						echo "<td>pending</td>";
						echo "<td> <a href='#'>Delete</a> / <a href='#'>Approve</a> </td>";
						
						// getting new table rows
						$ref_mails = unserialize($su->details);
		echo "</tr>";
		echo "<tr>";
					$email_string = array();
					$status_string = array();
					$action_string = array();
						foreach($ref_mails as $mail=>$status){
							$email_string[] = $mail;
							$status_string[] = ($status == 'n') ? 'pending' : 'approved';
							$action_string[] = "Re-send";
						}
							?>						
								
								<td></td>
								<td><?php echo implode('<br/>',$email_string) ?></td>								
								<td><?php  echo implode('<br/>',$status_string) ?></td>
								<td><?php  echo implode('<br/>',$action_string) ?></td>							
							
							<?php 					
		echo "</tr>";
		
					}					
				?>
						
			
			<?php 
			} //first foreach
			} //second foreach
			
			?>
				
	</table>
